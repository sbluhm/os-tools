""" Module to handle errors in Pythran. """


class PythranInternalError(Exception):

    """ Exception raise on Incorrect internal behavior in Pythran. """
