#ifndef PYTHONIC_DISPATCH_INDEX_HPP
#define PYTHONIC_DISPATCH_INDEX_HPP

#include "pythonic/include/__dispatch__/index.hpp"
#include "pythonic/operator_/indexOf.hpp"

#endif
