#ifndef PYTHONIC_CMATH_E_HPP
#define PYTHONIC_CMATH_E_HPP

#include "pythonic/include/cmath/e.hpp"

#endif
