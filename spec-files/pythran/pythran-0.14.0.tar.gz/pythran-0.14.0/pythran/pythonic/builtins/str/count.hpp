#ifndef PYTHONIC_BUILTIN_STR_COUNT_HPP
#define PYTHONIC_BUILTIN_STR_COUNT_HPP

#include "pythonic/include/builtins/str/count.hpp"
#include "pythonic/__dispatch__/count.hpp"

#endif
