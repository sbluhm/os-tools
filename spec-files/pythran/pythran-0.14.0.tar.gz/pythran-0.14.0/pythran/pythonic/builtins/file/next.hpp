#ifndef PYTHONIC_BUILTIN_FILE_NEXT_HPP
#define PYTHONIC_BUILTIN_FILE_NEXT_HPP

#include "pythonic/include/builtins/file/next.hpp"
#include "pythonic/__dispatch__/next.hpp"

#endif
