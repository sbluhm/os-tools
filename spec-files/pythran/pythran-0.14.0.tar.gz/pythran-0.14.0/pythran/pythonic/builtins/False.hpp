#ifndef PYTHONIC_BUILTIN_FALSE_HPP
#define PYTHONIC_BUILTIN_FALSE_HPP

#include "pythonic/include/builtins/False.hpp"

#endif
