#ifndef PYTHONIC_BUILTIN_SET_COPY_HPP
#define PYTHONIC_BUILTIN_SET_COPY_HPP

#include "pythonic/include/builtins/set/copy.hpp"
#include "pythonic/__dispatch__/copy.hpp"

#endif
