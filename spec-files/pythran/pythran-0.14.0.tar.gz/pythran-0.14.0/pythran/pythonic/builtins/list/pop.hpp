#ifndef PYTHONIC_BUILTIN_LIST_POP_HPP
#define PYTHONIC_BUILTIN_LIST_POP_HPP

#include "pythonic/include/builtins/list/pop.hpp"
#include "pythonic/__dispatch__/pop.hpp"

#endif
