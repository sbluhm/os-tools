#ifndef PYTHONIC_BUILTIN_PYTHRAN_KWONLY_HPP
#define PYTHONIC_BUILTIN_PYTHRAN_KWONLY_HPP
#include "pythonic/include/builtins/pythran/kwonly.hpp"
#endif
