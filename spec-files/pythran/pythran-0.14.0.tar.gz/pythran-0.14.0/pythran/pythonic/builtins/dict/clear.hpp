#ifndef PYTHONIC_BUILTIN_DICT_CLEAR_HPP
#define PYTHONIC_BUILTIN_DICT_CLEAR_HPP

#include "pythonic/include/builtins/dict/clear.hpp"
#include "pythonic/__dispatch__/clear.hpp"

#endif
