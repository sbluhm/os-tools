#ifndef PYTHONIC_BUILTIN_DICT_COPY_HPP
#define PYTHONIC_BUILTIN_DICT_COPY_HPP

#include "pythonic/include/builtins/dict/copy.hpp"
#include "pythonic/__dispatch__/copy.hpp"

#endif
