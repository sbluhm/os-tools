#ifndef PYTHONIC_BUILTIN_ISINSTANCE_HPP
#define PYTHONIC_BUILTIN_ISINSTANCE_HPP

#include "pythonic/include/builtins/isinstance.hpp"
#include "pythonic/include/builtins/pythran/is_none.hpp"

#endif
