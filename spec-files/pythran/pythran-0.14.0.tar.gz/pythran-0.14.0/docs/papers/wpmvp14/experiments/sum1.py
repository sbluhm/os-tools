#pythran export sum1(float [])
def sum1(r):
    return vsum(r*r)
