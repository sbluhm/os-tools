#pythran export sum0(float [])
def sum0(r):
    return vsum(r)
